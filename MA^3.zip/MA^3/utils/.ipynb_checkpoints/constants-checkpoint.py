
TRAIN_FILES = ['../cut_data/'
               ]

TEST_FILES = ['../cut_data/'
              ]

MAX_NB_VARIABLES = [2
                    ]

MAX_TIMESTEPS_LIST = [506
                      ]


NB_CLASSES_LIST = [7
                   ]